package com.example.demo.models;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
