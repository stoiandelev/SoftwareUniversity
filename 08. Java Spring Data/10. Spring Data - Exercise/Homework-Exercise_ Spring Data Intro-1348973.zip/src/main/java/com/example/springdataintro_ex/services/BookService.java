package com.example.springdataintro_ex.services;

public interface BookService {
}
