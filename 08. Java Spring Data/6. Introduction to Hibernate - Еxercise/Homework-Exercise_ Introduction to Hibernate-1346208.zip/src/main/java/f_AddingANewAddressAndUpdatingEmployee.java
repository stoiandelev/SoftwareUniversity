import entities.Address;
import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Scanner;

public class f_AddingANewAddressAndUpdatingEmployee {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU_Name");

        EntityManager entityManager = factory.createEntityManager();
        entityManager.getTransaction().begin();

        String address = "Vitoshka 15";
        Address newAddress = new Address();
        newAddress.setText(address);
        entityManager.persist(newAddress);

        Scanner scanner = new Scanner(System.in);

        String lastName = scanner.nextLine();

        entityManager.createQuery("UPDATE Employee e " +
                        "SET e.address = :address " +
                        "WHERE lastName = :name")
                .setParameter("address", newAddress)
                .setParameter("name", lastName)
                .executeUpdate();

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
