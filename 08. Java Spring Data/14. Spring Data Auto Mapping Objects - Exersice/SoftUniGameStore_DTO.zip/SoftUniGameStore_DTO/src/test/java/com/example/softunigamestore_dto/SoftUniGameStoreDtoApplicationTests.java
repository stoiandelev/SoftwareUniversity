package com.example.softunigamestore_dto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftUniGameStoreDtoApplicationTests {

    @Test
    void contextLoads() {
    }

}
