public enum Color {
    GREEN,
    RED,
    YELLOW

}
