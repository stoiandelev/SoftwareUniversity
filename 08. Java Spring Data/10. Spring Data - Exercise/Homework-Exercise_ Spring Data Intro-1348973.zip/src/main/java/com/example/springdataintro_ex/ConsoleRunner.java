package com.example.springdataintro_ex;

import com.example.springdataintro_ex.entities.Author;
import com.example.springdataintro_ex.entities.Book;
import com.example.springdataintro_ex.repositories.AuthorRepository;
import com.example.springdataintro_ex.repositories.BookRepository;
import com.example.springdataintro_ex.services.SeedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

@Component
public class ConsoleRunner implements CommandLineRunner {

    private final SeedService seedService;
    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    @Autowired
    public ConsoleRunner(SeedService seedService, BookRepository bookRepository, AuthorRepository authorRepository) {
        this.seedService = seedService;
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        //this.seedService.seedAuthors();
        //this.seedService.seedCategories();
        //this.seedService.seedAll();

        //this.booksAfter2000_01();
        // this.allAuthorsWithBookBefore_02();
        //this.allAuthorsOrderedByBookCount_03();
        this.printAllBooksByAuthorNameOrderByReleaseDate_04("George", "Powell");

    }

    private void printAllBooksByAuthorNameOrderByReleaseDate_04(String firstName, String lastName) {
        seedService.findAllBooksByAuthorFirstAndLastNameOrderByReleaseDate(firstName, lastName)
                .forEach(System.out::println);
    }

    private void allAuthorsOrderedByBookCount_03() {
        List<Author> authors = this.authorRepository.findAll();

        authors.stream()
                .sorted((l, r) -> r.getBooks().size() - l.getBooks().size())
                .forEach(author -> System.out.printf("%s %s -> %d%n", author.getFirstName(), author.getLastName(),
                        author.getBooks().size()));

    }

    private void allAuthorsWithBookBefore_02() {
        LocalDate year1990 = LocalDate.of(1990, 1, 31);

        List<Author> authors = this.authorRepository.findDistinctByBooksReleaseDateBefore(year1990);

        authors.forEach(author -> System.out.println(author.getFirstName() + " " + author.getLastName()));
    }

    private void booksAfter2000_01() {
        LocalDate year2000 = LocalDate.of(2000, 1, 1);

        List<Book> books = bookRepository.findByReleaseDateAfter(year2000);

        books.forEach(b -> System.out.println(b.getReleaseDate() + " " + b.getTitle()));
    }
}
