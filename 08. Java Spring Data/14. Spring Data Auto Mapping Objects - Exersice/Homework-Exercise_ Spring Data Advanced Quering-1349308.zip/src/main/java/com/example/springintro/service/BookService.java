package com.example.springintro.service;

import com.example.springintro.model.entity.Book;
import com.example.springintro.model.entity.EditionType;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

public interface BookService {
    void seedBooks() throws IOException;

    List<Book> findAllBooksByAgeRestriction(String ageRestriction);

    List<Book> findBooksByEditionAndCopies(EditionType gold, Integer copies);

    List<Book> findBooksByPrice(BigDecimal lower, BigDecimal higher);

    List<Book> findAllBooksNotReleasedIn(int year);

    List<Book> findBooksByReleaseDateBefore(String date);

    List<Book> findAllBooksContaining(String word);

    List<Book> findBooksByAuthor(String word);

    Integer findAllBooksWithLengthGreaterThan(int length);

    Book findBookByTitle(String title);

    int increaseBookCopies(String date, int volume);

    int deleteBooks(int number);
}
