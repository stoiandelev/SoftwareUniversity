package com.example.softunigamestore_dto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftUniGameStoreDtoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoftUniGameStoreDtoApplication.class, args);
    }

}
