package com.example.springdataintro_ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataIntroExApplicationTests {

    @Test
    void contextLoads() {
    }

}
