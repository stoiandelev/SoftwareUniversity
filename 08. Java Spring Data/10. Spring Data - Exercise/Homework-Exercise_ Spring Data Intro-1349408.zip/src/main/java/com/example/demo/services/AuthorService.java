package com.example.demo.services;

import com.example.demo.models.Author;

import java.util.Optional;

public interface AuthorService {
    Author getRandomAuthor();
}
