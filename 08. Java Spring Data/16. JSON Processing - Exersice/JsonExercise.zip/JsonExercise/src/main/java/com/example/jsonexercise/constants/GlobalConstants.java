package com.example.jsonexercise.constants;

public class GlobalConstants {

    public static final String RESOURCE_FILES_PATH = "src/main/resources/files/";
}
