import entities.Employee;
import entities.Project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Comparator;
import java.util.Scanner;
import java.util.Set;

public class _08_EmployeeWithProject {
    public static void main(String[] args) {

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");

        EntityManager entityManager = factory.createEntityManager();

        entityManager.getTransaction().begin();

        Scanner scanner = new Scanner(System.in);

        System.out.print("ID: ");
        Integer employeeID = Integer.parseInt(scanner.nextLine());

        Employee employee = entityManager.createQuery(
                "SELECT e FROM Employee e" +
                        " WHERE e.id = :id",
                Employee.class)
                .setParameter("id", employeeID)
                .getSingleResult();

        Set<Project> projects = employee.getProjects();

        System.out.println(employee.getFirstName() + " " + employee.getLastName()
                + " - " + employee.getJobTitle());

        projects.stream().sorted(Comparator.comparing(Project::getName))
                .forEach(project -> System.out.println(project.getName()));

        entityManager.getTransaction().commit();
    }
}
