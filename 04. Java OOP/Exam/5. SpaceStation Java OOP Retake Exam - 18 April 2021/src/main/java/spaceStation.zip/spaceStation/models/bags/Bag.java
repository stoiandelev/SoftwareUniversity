package spaceStation.models.bags;

import java.util.Collection;
import java.util.List;

public interface Bag {
    List<String> getItems();

}
