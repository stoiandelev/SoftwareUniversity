import entities.Employee;
import entities.Project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.*;

public class h_GetEmployeeWithProject {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU_Name");

        EntityManager entityManager = factory.createEntityManager();
        entityManager.getTransaction().begin();

        Scanner scanner = new Scanner(System.in);
        int id = Integer.parseInt(scanner.nextLine());

        entityManager.createQuery("SELECT e FROM Employee e " +
                "WHERE id = :id", Employee.class)
                        .setParameter("id", id)
                                .getResultStream()
                                        .forEach(e -> {
                                            System.out.printf("%s %s - %s%n", e.getFirstName(), e.getLastName(), e.getJobTitle());

                                            e.getProjects().stream()
                                                    .map(Project::getName)
                                                    .sorted()
                                                    .forEach(p -> System.out.printf("   %s%n", p));
                                        });

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
