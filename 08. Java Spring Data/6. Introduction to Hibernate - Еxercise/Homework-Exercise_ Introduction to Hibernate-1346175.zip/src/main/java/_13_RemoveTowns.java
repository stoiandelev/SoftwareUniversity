import entities.Address;
import entities.Town;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import java.util.Scanner;

public class _13_RemoveTowns {
    public static void main(String[] args) {

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");

        EntityManager entityManager = factory.createEntityManager();

        entityManager.getTransaction().begin();

        Scanner scanner = new Scanner(System.in);

        System.out.print("Name: ");
        String name = scanner.nextLine();

        Town town = entityManager.createQuery(
                "FROM Town t" +
                        " WHERE t.name = :townName",
                Town.class)
                .setParameter("townName", name)
                .getSingleResult();

        String townName = town.getName();

        List<Address> addressList = entityManager.createQuery(
                "FROM Address a" +
                        " WHERE a.town.name = :townName",
                Address.class)
                .setParameter("townName", name)
                .getResultList();

        int count = addressList.size();

        entityManager.createQuery(
                "UPDATE Employee e " +
                        " SET e.address = null" +
                        " WHERE e.address IN :addressList")
                .setParameter("addressList", addressList)
                .executeUpdate();

        addressList.forEach(entityManager::remove);
        entityManager.remove(town);

        entityManager.getTransaction().commit();

        if (count == 1) {
            System.out.printf("%d address in %s deleted", count, townName);
        }
        else {
            System.out.printf("%d addresses in %s deleted", count, townName);
        }
    }
}
