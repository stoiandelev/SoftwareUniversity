import entities.Town;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;

public class _02_ChangeCasing {
    public static void main(String[] args) {

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");

        EntityManager entityManager = factory.createEntityManager();

        entityManager.getTransaction().begin();

        Query fromTown = entityManager.createQuery("SELECT t FROM Town t", Town.class);

        List<Town> townList = fromTown.getResultList();

        for (Town town : townList) {
            String townName = town.getName();

            if (townName.length() <= 5) {
                String nameUpper = townName.toUpperCase();
                town.setName(nameUpper);

                entityManager.persist(town);
            }
        }

        entityManager.getTransaction().commit();
    }
}
