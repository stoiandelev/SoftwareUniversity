package com.example.springdataintro_ex.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
