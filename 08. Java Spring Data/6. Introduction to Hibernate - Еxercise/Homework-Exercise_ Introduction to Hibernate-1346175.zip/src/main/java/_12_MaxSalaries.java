import entities.Department;
import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.List;

public class _12_MaxSalaries {
    public static void main(String[] args) {

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");

        EntityManager entityManager = factory.createEntityManager();

        entityManager.getTransaction().begin();


         List<Object[]> resultList = entityManager.createQuery(
                "SELECT d.name, max(e.salary) FROM Employee e" +
                        " JOIN e.department AS d" +
                        " GROUP BY d.id" +
                        " HAVING max(e.salary) NOT BETWEEN 30000 AND 70000", Object[].class)
                 .getResultList();

         for (Object[] result : resultList) {
             System.out.printf("%s %.2f%n",
                     result[0], new BigDecimal(result[1].toString()));
         }


        entityManager.getTransaction().commit();
    }
}
