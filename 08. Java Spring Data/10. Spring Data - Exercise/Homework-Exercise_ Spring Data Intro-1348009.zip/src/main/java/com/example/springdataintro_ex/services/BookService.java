package com.example.springdataintro_ex.services;

import org.springframework.stereotype.Service;

@Service
public class BookService {

}
