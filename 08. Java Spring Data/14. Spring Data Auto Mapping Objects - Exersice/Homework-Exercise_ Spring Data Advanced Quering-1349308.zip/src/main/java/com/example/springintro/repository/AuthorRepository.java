package com.example.springintro.repository;

import com.example.springintro.model.entity.Author;
import com.example.springintro.model.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuthorRepository extends JpaRepository<Author, Long> {

    @Query("SELECT a FROM Author a ORDER BY a.books.size DESC")
    List<Author> findAllByBooksSizeDESC();

    List<Author> findAllAuthorsByFirstNameEndingWith(String word);

    @Query(value = "SELECT CONCAT(a.first_name, ' ', a.last_name, ' ', SUM(b.copies)) FROM authors a JOIN books b ON a.id = b.author_id \n" +
            "GROUP BY a.id\n" +
            "ORDER BY SUM(b.copies) DESC", nativeQuery = true)
    List<Object> findAuthorsByTotalCopies();

    @Query(value = "CALL udp_select_author_and_total_Books(:firstName, :lastName);", nativeQuery = true)
    int getTotalBooksByName(@Param("firstName") String firstName,@Param("lastName") String lastName);
}
