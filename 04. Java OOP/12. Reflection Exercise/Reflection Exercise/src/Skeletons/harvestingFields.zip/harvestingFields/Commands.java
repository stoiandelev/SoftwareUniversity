package Skeletons.harvestingFields;

public enum Commands {
    PUBLIC, PRIVATE, PROTECTED, ALL

}
