package com.example.jsonexercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonExerciseApplicationTests {

    @Test
    void contextLoads() {
    }

}
