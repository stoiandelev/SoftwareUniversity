package com.springintro.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
