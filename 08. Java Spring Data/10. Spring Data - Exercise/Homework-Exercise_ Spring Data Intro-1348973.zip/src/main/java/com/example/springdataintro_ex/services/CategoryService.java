package com.example.springdataintro_ex.services;

import com.example.springdataintro_ex.entities.Category;

import java.util.Set;

public interface CategoryService {
    Set<Category> getRandomCategories();
}
