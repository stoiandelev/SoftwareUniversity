package entities;

public enum CardType {
    GOLD, SILVER, PLATINUM
}
