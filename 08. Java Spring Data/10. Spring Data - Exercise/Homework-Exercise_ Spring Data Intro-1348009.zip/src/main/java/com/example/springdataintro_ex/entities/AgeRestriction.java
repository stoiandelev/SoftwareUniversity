package com.example.springdataintro_ex.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
