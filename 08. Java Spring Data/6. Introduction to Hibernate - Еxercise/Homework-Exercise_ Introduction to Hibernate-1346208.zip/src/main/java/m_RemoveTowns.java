import entities.Address;
import entities.Employee;
import entities.Town;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import java.util.Scanner;

public class m_RemoveTowns {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU_Name");

        EntityManager entityManager = factory.createEntityManager();
        entityManager.getTransaction().begin();
        Scanner scanner = new Scanner(System.in);

        String townToDelete = scanner.nextLine();

        List<Address> addresses = getAddressList(entityManager, townToDelete);

        for (Address address : addresses) {
            for (Employee employee : address.getEmployees()) {
                employee.setAddress(null);
            }
            entityManager.remove(address);
        }

        Town town = getTownByName(entityManager, townToDelete);

        entityManager.remove(town);


        if (addresses.size() == 1) {
            System.out.printf("1 address in %s deleted", townToDelete);
        } else {
            System.out.printf("%d addresses in %s deleted", addresses.size(), townToDelete);
        }

        entityManager.getTransaction().commit();
        entityManager.close();
    }

    private static Town getTownByName(EntityManager entityManager, String townToDelete) {
        return entityManager.createQuery("SELECT t FROM Town t WHERE t.name = :townName", Town.class)
                .setParameter("townName", townToDelete)
                .getSingleResult();
    }

    private static List<Address> getAddressList(EntityManager entityManager, String townToDelete) {
        return entityManager.createQuery("SELECT a FROM Address a WHERE a.town.name = :townName", Address.class)
                .setParameter("townName", townToDelete)
                .getResultList();
    }
}
