
import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.List;


public class _10_IncreaseSalaries {
    public static void main(String[] args) {

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");

        EntityManager entityManager = factory.createEntityManager();

        entityManager.getTransaction().begin();

        List<String> departmentList = new ArrayList<>();
        departmentList.add("Engineering");
        departmentList.add("Tool Design");
        departmentList.add("Marketing");
        departmentList.add("Information Services");


        entityManager.createQuery(
                "UPDATE Employee e" +
                        " SET e.salary = e.salary + e.salary * 0.12" +
                        " WHERE e.department IN (SELECT d FROM Department d WHERE d.name IN :departments)")
                .setParameter("departments", departmentList)
                .executeUpdate();

        entityManager.createQuery(
                "SELECT e FROM Employee e" +
                        " WHERE e.department.name IN :departments",
                Employee.class)
                .setParameter("departments", departmentList)
                .getResultList()
                .forEach(e -> System.out.printf("%s %s ($%.2f)%n",
                        e.getFirstName(), e.getLastName(), e.getSalary()));

        entityManager.getTransaction().commit();
    }
}
