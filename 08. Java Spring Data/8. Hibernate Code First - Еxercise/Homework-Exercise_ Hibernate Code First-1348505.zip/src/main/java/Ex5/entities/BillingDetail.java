package Ex5.entities;

public interface BillingDetail {
        String getNumber();
        User getOwner();
    }
