package com.springintro;

import com.springintro.model.entity.BookSummary;
import com.springintro.model.entity.EditionType;
import com.springintro.service.AuthorService;
import com.springintro.service.BookService;
import com.springintro.service.CategoryService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Scanner;

@Component
public class Runner implements CommandLineRunner {

    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;

    public Runner(CategoryService categoryService, AuthorService authorService, BookService bookService) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter exercise number you want to check: ");
        int exerciseNumber = Integer.parseInt(scanner.nextLine());

        switch (exerciseNumber) {
            case 0:
                System.out.println("Seed data. Now check what you have in database.");
                seedData();
                break;
            case 1:
                System.out.println("01.Books Titles by Age Restriction");
                String restriction = scanner.nextLine();
                this.bookService
                        .findByAgeRestriction(restriction)
                        .forEach(System.out::println);
                break;
            case 2:
                System.out.println("02.Golden Books");
                EditionType golden = EditionType.GOLD;
                int copies = 5000;
                this.bookService.findAllTitlesWithLessThan(golden, copies)
                        .forEach(System.out::println);
                break;
            case 3:
                System.out.println("03.Books by Price");
                this.bookService.findAllWithPriceNotBetween(5, 40)
                        .forEach(b -> System.out.println(b.getTitle() + " - $" + b.getPrice()));
                break;
            case 4:
                System.out.println("04.Not Released Books");
                System.out.print("Enter year that books are not released in: ");
                int releasedYear = 0;
                try {
                    releasedYear = Integer.parseInt(scanner.nextLine());
                } catch (IllegalArgumentException e) {
                    System.out.println("You have to enter a number. Try again!");
                }
                this.bookService.findNotReleasedIn(releasedYear)
                        .forEach(b -> System.out.println(b.getTitle()));
                break;
            case 5:
                System.out.println("05.Books Released Before Date");
                System.out.print("Please enter date in the format dd-MM-yyyy: ");
                String date = scanner.nextLine();
                this.bookService.findBooksReleasedBefore(date)
                        .forEach(b -> System.out.printf("%s %s %.2f%n",
                                b.getTitle(), b.getEditionType(), b.getPrice()));
                break;
            case 6:
                System.out.println("06.Authors Search");
                System.out.print("Please enter the letters you want the author's first name to end with: ");
                String lettersEndsWith = scanner.nextLine();
                this.authorService.findByFirstNameEndingWith(lettersEndsWith)
                        .stream()
                        .map(a -> a.getFirstName() + " " + a.getLastName())
                        .forEach(System.out::println);
                break;
            case 7:
                System.out.println("07.Books Search");
                System.out.print("Please enter the letters you want the title's name to contains: ");
                String lettersContains = scanner.nextLine();
                this.bookService.findAllTitlesContaining(lettersContains)
                        .forEach(System.out::println);
                break;
            case 8:
                System.out.println("08.Book Titles Search");
                System.out.print("Please enter the letters you want the authors last name to starts with: ");
                String search = scanner.nextLine();
                this.bookService.findByAuthorLastNameStartsWith(search)
                        .forEach(b -> System.out.printf("%s (%s %s)%n",
                                b.getTitle(), b.getAuthor().getFirstName(),
                                b.getAuthor().getLastName()));
                System.out.println(" *** *** Check results manually in DB, because we insert random Authors for every books. *** ***");
                break;
            case 9:
                System.out.println("09.Count Books");
                System.out.print("Please enter length of title: ");
                int length = 0;
                try {
                    length = Integer.parseInt(scanner.nextLine());
                } catch (IllegalArgumentException e) {
                    System.out.println("You have to enter a number. Try again!");
                }
                int totalBooks = this.bookService.countBooksWithTitleLongerThan(length);
                System.out.printf("There are %d books with longer title than %d symbols%n",
                        totalBooks, length);
                break;
            case 10:
                System.out.println("10.Total Book Copies");
                this.authorService.getWithTotalCopies()
                        .forEach(a -> System.out.println(a.getFirstName() + " " + a.getLastName() + " - " + a.getTotalCopies()));
                System.out.println(" *** *** Check results manually in DB, because we insert random Authors for every books. *** ***");
                break;
            case 11:
                System.out.println("11.Reduced Book");
                System.out.print("Please enter the title of book: ");
                String title = scanner.nextLine();
                BookSummary summary = this.bookService.getInformationForTitle(title);
                System.out.println(summary.getTitle() + " " + summary.getEditionType() +
                        " " + summary.getAgeRestriction() + " " + summary.getPrice());
                break;
            case 12:
                System.out.println("12.* Increase Book Copies");
                System.out.print("Please enter date in the format dd MMM yyyy: ");
                String dateAfter = scanner.nextLine().replace(" ", "-");
                System.out.print("Please enter number of book copies each book should be increased with: ");
                int amount = Integer.parseInt(scanner.nextLine());
                int booksUpdated = this.bookService.addCopiesToBooksAfter(dateAfter, amount);
                System.out.println(amount * booksUpdated);
                break;
            case 13:
                System.out.println("13.* Remove Books");
                System.out.print("Please enter number of book copies: ");
                int number = Integer.parseInt(scanner.nextLine());
                int deleteCount = this.bookService.deleteWithCopiesLessThan(number);
                System.out.println(deleteCount + " books were deleted.");
                break;
            case 14:
                System.out.println("14.* Stored Procedure");
                // You can use this query to make procedure in MySQL Workbench
            /*
            DELIMITER %%
            CREATE PROCEDURE usp_total_amount_of_books_by_author_name(author_first_name VARCHAR(30), author_last_name VARCHAR(30))
            BEGIN
                SELECT COUNT(b.id) FROM books AS b
                JOIN authors AS a
                ON a.id = b.author_id
                WHERE a.first_name = author_first_name
                AND a.last_name = author_last_name;
            END
            %%
            DELIMITER ;

            CALL usp_total_amount_of_books_by_author_name("Roger","Porter");
             */
                System.out.print("Enter author's first and last name: ");
                String fullName = scanner.nextLine();
                String firstName = fullName.split("\\s+")[0];
                String lastName = fullName.split("\\s+")[1];
                int bookNumber = this.bookService.countBooksWithFirstNameAndLastName(firstName, lastName);
                System.out.println(bookNumber);
                break;
            default:
                System.out.println("You have to entered number between 0 and 14. Try again!");
        }
    }

    private void seedData() throws IOException {
        categoryService.seedCategories();
        authorService.seedAuthors();
        bookService.seedBooks();
    }
}
