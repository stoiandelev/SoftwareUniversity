package com.example.springintro.service.impl;

import com.example.springintro.model.entity.*;
import com.example.springintro.repository.AuthorRepository;
import com.example.springintro.repository.BookRepository;
import com.example.springintro.service.AuthorService;
import com.example.springintro.service.BookService;
import com.example.springintro.service.CategoryService;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class BookServiceImpl implements BookService {

    private static final String BOOKS_FILE_PATH = "Ex_skeleton\\src\\main\\resources\\files\\books.txt";

    private final BookRepository bookRepository;
    private final AuthorService authorService;
    private final CategoryService categoryService;

    public BookServiceImpl(BookRepository bookRepository, AuthorRepository authorRepository, AuthorService authorService, CategoryService categoryService) {
        this.bookRepository = bookRepository;
        this.authorService = authorService;
        this.categoryService = categoryService;
    }

    @Override
    public void seedBooks() throws IOException {
        if (bookRepository.count() > 0) {
            return;
        }

        Files
                .readAllLines(Path.of(BOOKS_FILE_PATH))
                .forEach(row -> {
                    String[] bookInfo = row.split("\\s+");

                    Book book = createBookFromInfo(bookInfo);

                    bookRepository.save(book);
                });
    }

    @Override
    public List<Book> findAllBooksByAgeRestriction(String ageRestriction) {

        AgeRestriction ageRest = AgeRestriction.valueOf(ageRestriction);

        return this.bookRepository.findAllBooksByAgeRestriction(ageRest);
    }

    @Override
    public List<Book> findBooksByEditionAndCopies(EditionType gold, Integer copies) {

        return this.bookRepository.findAllBooksByEditionTypeAndCopiesLessThan(gold, copies);
    }

    @Override
    public List<Book> findBooksByPrice(BigDecimal lower, BigDecimal higher) {


        return this.bookRepository.findAllBooksByPriceLessThanOrPriceGreaterThan(lower, higher);
    }

    @Override
    public List<Book> findAllBooksNotReleasedIn(int year) {

        return this.bookRepository.findAllBooksByReleaseDateYearNotIn(year);
    }

    @Override
    public List<Book> findBooksByReleaseDateBefore(String date) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate parsedDate = LocalDate.parse(date, formatter);

        return this.bookRepository.findAllBooksByReleaseDateBefore(parsedDate);
    }

    @Override
    public List<Book> findAllBooksContaining(String word) {

        return this.bookRepository.findAllBooksByTitleContaining(word);
    }

    @Override
    public List<Book> findBooksByAuthor(String word) {

        return this.bookRepository.findAllBooksByAuthorLastNameStartingWith(word);
    }

    @Override
    public Integer findAllBooksWithLengthGreaterThan(int length) {

        return this.bookRepository.findAllBooksByTitleLengthGreaterThan(length);
    }

    @Override
    public Book findBookByTitle(String title) {

        return this.bookRepository.findBookByTitle(title);
    }

    @Override
    public int increaseBookCopies(String date, int volume) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
        LocalDate parsedDate = LocalDate.parse(date, formatter);

        return this.bookRepository.increaseBookCopies(parsedDate, volume);
    }

    @Override
    public int deleteBooks(int number) {

        return this.bookRepository.deleteByCopiesLessThan(number);
    }

    private Book createBookFromInfo(String[] bookInfo) {
        EditionType editionType = EditionType.values()[Integer.parseInt(bookInfo[0])];
        LocalDate releaseDate = LocalDate
                .parse(bookInfo[1], DateTimeFormatter.ofPattern("d/M/yyyy"));
        Integer copies = Integer.parseInt(bookInfo[2]);
        BigDecimal price = new BigDecimal(bookInfo[3]);
        AgeRestriction ageRestriction = AgeRestriction
                .values()[Integer.parseInt(bookInfo[4])];
        String title = Arrays.stream(bookInfo)
                .skip(5)
                .collect(Collectors.joining(" "));

        Author author = authorService.getRandomAuthor();
        Set<Category> categories = categoryService
                .getRandomCategories();

        return new Book(editionType, releaseDate, copies, price, ageRestriction, title, author, categories);

    }
}
