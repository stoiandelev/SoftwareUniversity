package com.example.springdataintro_ex.services;

import com.example.springdataintro_ex.entities.Author;

public interface AuthorService {
    Author getRandomAuthor();
}
