package com.example.demo;

import com.example.demo.models.Author;
import com.example.demo.models.Book;
import com.example.demo.repositories.AuthorRepository;
import com.example.demo.repositories.BookRepository;
import com.example.demo.services.SeedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

@Component
public class ConsoleRunner implements CommandLineRunner {

    private final SeedService seedService;

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    @Autowired
    public ConsoleRunner(SeedService seedService, BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
        this.seedService = seedService;
    }

    @Override
    public void run(String... args) throws Exception {
        _01_booksAfter2000();
        _02_getAuthorsWithBookBefore1990();
        _03_getAuthorsOrderedByBooks();
        _04_getBooksByAuthor();
    }

    private void _01_booksAfter2000() {

        LocalDate year2000 = LocalDate.of(2000, 1, 1);

        List<Book> books = this.bookRepository.findByReleaseDateAfter(year2000);

        for (Book book :
                books) {
            System.out.println("The book's title is: " + book.getTitle());
        }
    }

    private void _02_getAuthorsWithBookBefore1990() {
        LocalDate year1990 = LocalDate.of(1990, 1, 1);

        List<Author> authors = this.authorRepository.findDistinctByBooksReleaseDateBefore(year1990);

        for (Author a :
                authors) {
            System.out.println(a.getFirstName() + " " + a.getLastName());
        }
    }

    private void _03_getAuthorsOrderedByBooks() {

        List<Author> authors = this.authorRepository.findAll();

        authors.stream()
                .sorted((a1, a2) -> a2.getBooks().size() - a1.getBooks().size())
                .forEach(author -> {
                    System.out.printf("%s %s has %d books.%n", author.getFirstName(),
                            author.getLastName(),
                            author.getBooks().size());
                });
    }

    private void _04_getBooksByAuthor() {

        Author author = authorRepository.findAuthorByFirstNameAndLastName("George", "Powell");

        List<Book> books = this.bookRepository.findBooksByAuthor(author);

        books.stream()
                .sorted(Comparator.comparing(Book::getReleaseDate))
                .sorted(Comparator.comparing(Book::getTitle))
                .forEach(book -> {
                    System.out.printf("%s %s %d%n", book.getTitle(), book.getReleaseDate().toString(), book.getCopies());
                });
    }

}
