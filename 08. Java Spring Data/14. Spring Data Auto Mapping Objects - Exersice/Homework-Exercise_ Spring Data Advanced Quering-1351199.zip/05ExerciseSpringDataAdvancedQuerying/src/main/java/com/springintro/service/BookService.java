package com.springintro.service;

import com.springintro.model.entity.Book;
import com.springintro.model.entity.BookSummary;
import com.springintro.model.entity.EditionType;

import java.io.IOException;
import java.util.List;

public interface BookService {
    void seedBooks() throws IOException;

    List<String> findByAgeRestriction(String ageRestriction);

    List<String> findAllTitlesWithLessThan(EditionType golden, int copies);

    List<Book> findAllWithPriceNotBetween(float lowerBound, float upperBound);

    List<Book> findNotReleasedIn(int releasedYear);

    List<Book> findBooksReleasedBefore(String date);

    List<String> findAllTitlesContaining(String lettersContains);

    List<Book> findByAuthorLastNameStartsWith(String search);

    int countBooksWithTitleLongerThan(int length);

    BookSummary getInformationForTitle(String title);

    int addCopiesToBooksAfter(String releasedDate, int numberToIncrease);

    int deleteWithCopiesLessThan(int amount);

    int countBooksWithFirstNameAndLastName(String firstName, String lastName);
}
