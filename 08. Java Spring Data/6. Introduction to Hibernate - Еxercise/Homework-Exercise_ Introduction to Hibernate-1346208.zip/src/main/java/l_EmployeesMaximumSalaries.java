import entities.Department;
import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.math.BigDecimal;

public class l_EmployeesMaximumSalaries {
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("PU_Name");

        EntityManager entityManager = factory.createEntityManager();
        entityManager.getTransaction().begin();

        entityManager.createQuery("SELECT d FROM Department d", Department.class)
                .getResultStream()
                .forEach(d -> {
                    Employee employee = d.getEmployees().stream().min((e1, e2) -> e2.getSalary().compareTo(e1.getSalary()))
                            .orElse(null);

                    if (employee != null
                            && (employee.getSalary().compareTo(BigDecimal.valueOf(30000)) < 0
                            || employee.getSalary().compareTo(BigDecimal.valueOf(70000)) > 0)) {
                        System.out.printf("%s %.2f%n", d.getName(), employee.getSalary());
                    }
                });

        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
