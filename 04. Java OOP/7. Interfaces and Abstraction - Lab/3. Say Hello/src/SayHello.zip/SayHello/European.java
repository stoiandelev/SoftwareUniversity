package SayHello;

public class European extends PersonImpl {
    public European(String name) {
        super(name);
    }


}
