public enum Card {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
}
