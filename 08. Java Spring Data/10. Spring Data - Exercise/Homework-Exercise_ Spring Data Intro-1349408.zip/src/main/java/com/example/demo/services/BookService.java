package com.example.demo.services;

import com.example.demo.models.Book;

import java.util.Set;

public interface BookService {

}
