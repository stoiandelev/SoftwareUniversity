package com.example.springdataintro_ex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataIntroExApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringDataIntroExApplication.class, args);
    }

}
