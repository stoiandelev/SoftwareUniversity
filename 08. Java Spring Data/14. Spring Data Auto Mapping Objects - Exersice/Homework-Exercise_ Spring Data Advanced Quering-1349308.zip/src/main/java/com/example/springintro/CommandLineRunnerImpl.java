package com.example.springintro;

import com.example.springintro.model.entity.Book;
import com.example.springintro.model.entity.EditionType;
import com.example.springintro.service.AuthorService;
import com.example.springintro.service.BookService;
import com.example.springintro.service.CategoryService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;

@Component
public class CommandLineRunnerImpl implements CommandLineRunner {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;

    public CommandLineRunnerImpl(CategoryService categoryService, AuthorService authorService, BookService bookService) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... args) throws Exception {
        //seedData();

        this._01_Books_Titles_by_Age_Restriction();
        this._02_Golden_Books();
        this._03_Books_by_Price();
        this._04_Not_Released_Books();
        this._05_Books_Released_Before_Date();
        this._06_Authors_Search();
        this._07_Books_Search();
        this._08_Book_Titles_Search();
        this._09_Count_Books();
        this._10_Total_Book_Copies();
        this._11_Reduced_Book();
        this._12_Increase_Book_Copies();
        this._13_Remove_Books();
        this._14_Stored_Procedure();
    }

    private void _14_Stored_Procedure() throws IOException {

        String[] names = reader.readLine().split("\\s+");

        String firstName = names[0];
        String lastName = names[1];

        int totalBooksByName = this.authorService.getTotalBooksByName(firstName, lastName);

        System.out.println(firstName + " " + lastName + " has written " + totalBooksByName + " books");
    }

    private void _13_Remove_Books() throws IOException {

        int number = Integer.parseInt(reader.readLine());

        System.out.println(this.bookService.deleteBooks(number));
    }

    private void _12_Increase_Book_Copies() throws IOException {

        String date = reader.readLine();
        int volume = Integer.parseInt(reader.readLine());

        int totalBooksIncreased = this.bookService.increaseBookCopies(date, volume);

        int result = volume * totalBooksIncreased;

        System.out.println(result);
    }

    private void _11_Reduced_Book() throws IOException {

        String title = reader.readLine();

        Book bookByTitle = this.bookService.findBookByTitle(title);

        System.out.println(bookByTitle.getTitle() + " " +
                bookByTitle.getEditionType().name() + " " +
                bookByTitle.getAgeRestriction().name() + " " +
                bookByTitle.getPrice());
    }

    private void _10_Total_Book_Copies() {

        this.authorService.findAuthorsByTotalCopies().
                forEach(a -> System.out.println(a.toString()));
    }

    private void _09_Count_Books() throws IOException {

        int length = Integer.parseInt(reader.readLine());

        Integer result = this.bookService.findAllBooksWithLengthGreaterThan(length);

        System.out.println("There are " + result + " books with longer title than " + length + " symbols");
    }

    private void _08_Book_Titles_Search() throws IOException {

        String word = reader.readLine();

        this.bookService.findBooksByAuthor(word).
                forEach(b -> System.out.println(
                        b.getTitle() + " (" +
                                b.getAuthor().getFirstName() + " " +
                                b.getAuthor().getLastName() + ")"));
    }

    private void _07_Books_Search() throws IOException {

        String word = reader.readLine();

        this.bookService.findAllBooksContaining(word).
                forEach(b -> System.out.println(b.getTitle()));
    }

    private void _06_Authors_Search() throws IOException {

        String word = reader.readLine();

        this.authorService.findAuthorsByStringEndingWith(word).
                forEach(a -> System.out.println(a.getFirstName() + " " + a.getLastName()));
    }

    private void _05_Books_Released_Before_Date() throws IOException {

        String date = reader.readLine();

        this.bookService.findBooksByReleaseDateBefore(date).
                forEach(b -> System.out.println(b.getTitle() + " " + b.getEditionType() + " " + b.getPrice()));
    }

    private void _04_Not_Released_Books() throws IOException {

        int year = Integer.parseInt(reader.readLine());

        this.bookService.findAllBooksNotReleasedIn(year).
                forEach(b -> System.out.println(b.getTitle()));
    }

    private void _03_Books_by_Price() {

        this.bookService.findBooksByPrice(BigDecimal.valueOf(5), BigDecimal.valueOf(40))
                .forEach(b -> System.out.println(b.getTitle() + " - $" + b.getPrice()));
    }

    private void _02_Golden_Books() {

        this.bookService.findBooksByEditionAndCopies(EditionType.GOLD, 5000).
                forEach(b -> System.out.println(b.getTitle()));
    }

    private void _01_Books_Titles_by_Age_Restriction() throws IOException {

        String ageRestriction = reader.readLine().toUpperCase();

        this.bookService.findAllBooksByAgeRestriction(ageRestriction).
                forEach(b -> System.out.println(b.getTitle()));
    }

    private void seedData() throws IOException {
        categoryService.seedCategories();
        authorService.seedAuthors();
        bookService.seedBooks();
    }
}
