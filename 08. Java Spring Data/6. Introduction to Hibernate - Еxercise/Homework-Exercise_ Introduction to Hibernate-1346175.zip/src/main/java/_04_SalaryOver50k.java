import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;
import java.util.Scanner;

public class _04_SalaryOver50k {
    public static void main(String[] args) {

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("soft_uni");

        EntityManager entityManager = factory.createEntityManager();

        entityManager.getTransaction().begin();


        List<String> nameList = entityManager
                .createQuery(
                        "SELECT e.firstName FROM Employee e" +
                                " WHERE e.salary > 50000",
                        String.class)
                .getResultList();


       for (String name : nameList) {
           System.out.println(name);
       }

        entityManager.getTransaction().commit();
    }
}
