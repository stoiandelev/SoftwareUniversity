package Single;

import Single.Animal;

public class Dog extends Animal {
    public void bark() {
        System.out.println("barking...");
    }
}
