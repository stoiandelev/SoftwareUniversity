package primo.shoppinglist.data.entities.enums;

public enum CategoryName {
    FOOD, DRINK, HOUSEHOLD, OTHER
}
